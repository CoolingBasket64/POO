package Juegos;

public interface Juegos {
    void iniciar();
    void jugar();
    void finalizar();
}
