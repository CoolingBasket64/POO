package FigurasG;

public abstract class Figura {
    public abstract void calcularArea();
}